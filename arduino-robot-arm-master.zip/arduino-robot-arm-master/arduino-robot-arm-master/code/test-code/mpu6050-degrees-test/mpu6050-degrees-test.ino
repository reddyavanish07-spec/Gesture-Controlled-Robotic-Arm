/******************************************************************************
  Author: Smartbuilds.io
  YouTube: https://www.youtube.com/channel/UCGxwyXJWEarxh2XWqvygiIg
  Fork your own version: https://github.com/EbenKouao/arduino-robotic-arm
  Date: 28/12/2020
  Description: Test the MPU relative position X & Y co-ord in degreed

******************************************************************************/

#include<Wire.h>

#define button 8
int state = 0;
int buttonState = 0;
int check = 1;
int nil = 0;

const int MPU2 = 0x69, MPU1 = 0x68;

int16_t AcX1, AcY1, AcZ1, Tmp1, GyX1, GyY1, GyZ1;

double x;
double y;
double z;

int response_time = 40;

void setup() {
  pinMode(3, OUTPUT);
  Wire.begin();
  Wire.beginTransmission(MPU1);
  Wire.write(0x6B);// PWR_MGMT_1 register
  Wire.write(0); // set to zero (wakes up the MPU-6050)
  Wire.endTransmission(true); Wire.begin();
  Wire.beginTransmission(MPU2);
  Wire.write(0x6B);// PWR_MGMT_1 register
  Wire.write(0); // set to zero (wakes up the MPU-6050)
  Wire.endTransmission(true);
  Serial.begin(4800);
  delay(1000);

}
void loop() {
  //get values for first mpu having address of 0x68
  GetMpuValue1(MPU1);
}

void GetMpuValue1(const int MPU)
{
  Wire.beginTransmission(MPU);
  Wire.write(0x3B);
  Wire.endTransmission(false);

  Wire.requestFrom(MPU, 14, true);

  AcX1 = Wire.read() << 8 | Wire.read();
  AcY1 = Wire.read() << 8 | Wire.read();
  AcZ1 = Wire.read() << 8 | Wire.read();

  Tmp1 = Wire.read() << 8 | Wire.read();

  GyX1 = Wire.read() << 8 | Wire.read();
  GyY1 = Wire.read() << 8 | Wire.read();
  GyZ1 = Wire.read() << 8 | Wire.read();

  // Calculate angles directly
  float angleX = atan2(AcY1, AcZ1) * 180.0 / PI;
  float angleY = atan2(-AcX1, sqrt((long)AcY1 * AcY1 + (long)AcZ1 * AcZ1)) * 180.0 / PI;
  float angleZ = atan2(AcX1, AcY1) * 180.0 / PI;

  Serial.print("AcX: ");
  Serial.print(AcX1);

  Serial.print("  AcY: ");
  Serial.print(AcY1);

  Serial.print("  AcZ: ");
  Serial.print(AcZ1);

  Serial.print("   AngleX: ");
  Serial.print(angleX);

  Serial.print("   AngleY: ");
  Serial.print(angleY);

  Serial.print("   AngleZ: ");
  Serial.println(angleZ);

  delay(100);
}